Logic.selectOverview = function() {    
  Logic.state.currScreen = ScreenEnum.OVERVIEW_SCREEN;
  Logic.clearSelection();
  Logic.redraw();
}

Logic.drawOverview = function() {
  Board.cls();  
	
	Board.printAt(0,0,  "                                                                                                                       ", "stHeader").on("click", Logic.selectOverview); 
  Board.printAt(1 ,0, "Overview  ", "stHeader").on("click", Logic.selectOverview);  
  Board.printAt(10,0, "    Map   ", "stHeader").on("click", Logic.selectMap);      
	Board.printAt(20,0, "  Mission ", "stHeader").on("click", Logic.selectMission);
  Board.printAt(30,0, "   Crew   ", "stHeader").on("click", Logic.selectCrew);
  Board.printAt(40,0, "   Log    ", "stHeader").on("click", Logic.selectLog);  
  Board.printAt(60,0, "   Back   ", "stHeader").on("click", Logic.selectOverview);   
  Board.printAt(140,0,"   Turn   ", "stHeader").on("click", Logic.selectNextTurn);
	       
  nextLine = 3;  

  switch(Logic.state.guiCommand) {
    case GuiCommandEnum.NONE :
      nextLine = Overview_drawMenu(nextLine);
    break;
    case GuiCommandEnum.CREW_SELECTION:
    case GuiCommandEnum.CREW_EQUIPMENT:
    case GuiCommandEnum.CREW_MOVEMENT:
    case GuiCommandEnum.CREW_ACTION:
    case GuiCommandEnum.CREW_INFORMATION:       
      nextLine = Overview_drawCrew(nextLine);
    break; 
    case GuiCommandEnum.LOCATION_SELECTION:
      nextLine = Overview_drawLocation(nextLine);
    break;    
    case GuiCommandEnum.BUILD_SELECTION:
      nextLine = Overview_drawBuild(nextLine);
    break;
  }
  

  
  if(IS_SET(Logic.state.interaction_flags, GameInteractionFlag.WAITING_FOR_STORY)) {
    nextLine = Overview_drawStory(nextLine);
  } else {
    nextLine = Overview_drawLocationDetails(nextLine);
    
    if(Logic.state.target.data != null) {
      nextLine++;
      nextLine = Overview_drawTargetOptions(nextLine);   
    }  

    nextLine = Overview_drawMap(nextLine);
    nextLine = Overview_drawChatter(nextLine);
  }
}

function Overview_drawMenu(nextLine) {
  Board.printAt(0,2," Menu                         ", "stInfoHeader");  
  nextLine = 3;
  
  cell = Board.printAt(0,nextLine,"Crew           ", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.CREW_SELECTION},     Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"Location       ", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.LOCATION_SELECTION}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"Build          ", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.BUILD_SELECTION},    Logic.interact);
  nextLine++;
  
  return nextLine;
}

function Overview_drawLocation(nextLine) {
  Board.printAt(0,2," Menu                         ", "stInfoHeader");  
  nextLine = 3;
  
  Board.printAt(0,nextLine,"Back           ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  nextLine++;
  
  Board.printAt(0,nextLine," Location                     ", "stInfoHeader"); 
  nextLine++;  

  cell = Board.printAt(0,nextLine,"dig            ", "stGreen").on("click", {act : "dig", what : Logic.state.currLoc}, Logic.interact);
  nextLine++;
 
  return nextLine;
}

function Overview_drawBuild(nextLine) {
  Board.printAt(0,2," Menu                         ", "stInfoHeader");  
  nextLine = 3;
  
  Board.printAt(0,nextLine,"Back           ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  nextLine++;
  
  Board.printAt(0,nextLine," Build                        ", "stInfoHeader"); 
  nextLine++;  

  cell = Board.printAt(0,nextLine,"airlock        ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"empty room     ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"living quarters", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"storage        ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"command        ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;  
  cell = Board.printAt(0,nextLine,"workshop       ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;  
  cell = Board.printAt(0,nextLine,"laboratory     ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"medical        ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(0,nextLine,"power          ", "stGreen").on("click", {act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  
  
  return nextLine;
}

function Overview_drawCrew(nextLine) {
  crewRef = Logic.state.crew;  
  Board.printAt(0,2," Menu                         ", "stInfoHeader");  
  nextLine = 3;
  
  Board.printAt(0,nextLine,"Back           ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  nextLine++;
  
  Board.printAt(0,nextLine," Crew                         ", "stInfoHeader"); 
  nextLine++;  

  for(i=0; i < crewRef.length; i++) {

    crew = crewRef[i];
    if(Logic.state.who.type == SelectionEnum.CREW && Logic.state.who.data == crew) {
      Board.printAt(0, nextLine, crew.name, "stGreen highlight");
    } else {
      Board.printAt(0, nextLine, crew.name, "stGreen").on("click", { act : "crew", what : crew}, Logic.interact);
    }
    
    nextLine++;
  }
  
   if(Logic.state.who.type == SelectionEnum.CREW) {
    crew = SELECTED_MOB();
    
    nextLine++;
    Board.printAt(0,nextLine,"Interact                      ", "stInfoHeader");  
    nextLine++;
    
    cell = Board.printAt(0,nextLine,"Movement       ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.CREW_MOVEMENT}, Logic.interact);
    nextLine++;   
    if(Logic.state.guiCommand == GuiCommandEnum.CREW_MOVEMENT) { 
      cell.addClass("highlight"); 
    }

    cell = Board.printAt(0,nextLine,"Action         ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.CREW_ACTION}, Logic.interact);;
    nextLine++;  
    if(Logic.state.guiCommand == GuiCommandEnum.CREW_ACTION) { 
      cell.addClass("highlight"); 
    }
    
    cell = Board.printAt(0,nextLine,"Equipment      ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.CREW_EQUIPMENT}, Logic.interact);  
    nextLine++;    
    if(Logic.state.guiCommand == GuiCommandEnum.CREW_EQUIPMENT) { 
      cell.addClass("highlight");
    }
    
    cell = Board.printAt(0,nextLine,"Information    ", "stGreen").on("click",{ act : "gui", what : GuiCommandEnum.CREW_INFORMATION}, Logic.interact);  
    nextLine++;    
    if(Logic.state.guiCommand == GuiCommandEnum.CREW_INFORMATION) { 
      cell.addClass("highlight");
    }
    
    if(Logic.state.guiCommand == GuiCommandEnum.CREW_EQUIPMENT) {
      nextLine++;
      Board.printAt(0,nextLine," Equipment                    ", "stInfoHeader");
      nextLine++;
      
      equipmentPlace = nextLine;
      
      Board.printAt(0,nextLine,"Wearing    ");
      nextLine++;
      Board.printAt(0,nextLine,"Holding    ");
      nextLine++;
      Board.printAt(0,nextLine,"Equipment  ");
      nextLine++;
      Board.printAt(0,nextLine,"Utility    ");
      nextLine++;
      Board.printAt(0,nextLine,"Backpack   ");
      nextLine++;
      Board.printAt(0,nextLine,"Belt       ");
      nextLine++;
      
      crew = Logic.state.who.data;
      for(var i=0;i < EquipSlotEnum.EQUIP_MAX; i++) {
        item = crew.inventory[i];
        if(item != null) {
          Board.printAt(15, equipmentPlace, item.name, "stGreen");
        }
        equipmentPlace++;
      }
    }
    
    if(Logic.state.guiCommand == GuiCommandEnum.CREW_MOVEMENT) {
      nextLine++;
      Board.printAt(0,nextLine," Movement                     ", "stInfoHeader");
      nextLine++;
      
      Board.printAt(0,nextLine,"Move here  ", "stGreen").on("click",{ act : "crew_move", what : Logic.state.currLocation}, Logic.interact);;
    }
  }
    
  return nextLine;
}

function Overview_drawLocationDetails(nextLine) {
  Board.printAt(32, 2," Location                                                     ", "stInfoHeader");
  nextLine = 3; 
  parentList = [];
  currLoc    = Logic.state.currLocation;
 
 var count=0;
  while(currLoc != null && count < 3) {
    parentList.push(currLoc);
    currLoc = currLoc.ll_location;
    count++;
  }
  countChars = 0;
  
  for(var i=parentList.length -1; i >= 0; i--) {
    locName = parentList[i].name;
    Board.printAt(32 + countChars, nextLine, locName, "stGreen").on("click",{ act : "location", what : parentList[i]}, Logic.interact);       
    countChars += locName.length + 1;
    if(i != 0) {
      Board.printAt(32 + countChars, nextLine, ">");
      countChars += 2;
    }
  }
  nextLine++;
  nextLine++;
  
  tags = [];
  descriptions = Logic.describe(Logic.state.currLocation, tags);
  descriptions.forEach(function(el) {
    Board.printAt(32, nextLine, el);
    nextLine++;
  });
  
  tags.forEach(function(tag) {
    element = $("#"+tag.id);
    if(tag.item != null) {      
      if(Logic.state.target.data == tag.item) {
        element.addClass("stGreen highlight");
      } else {
        element.addClass("stBlue highlight");
      }
      element.on("click", { act:"targetItem", what:tag.item }, Logic.interact);
    }
  });
    
  if(Logic.state.target.data != null) {
    nextLine++;
    Board.printAt(32, nextLine," Information                                                 ", "stInfoHeader");  
    nextLine++;
    
    target = Logic.state.target.data;
    descriptions = Logic.describe(target, tags);
    descriptions.forEach(function(el) {
      Board.printAt(32, nextLine, el);
      nextLine++;
    });
  }
  
  return nextLine;
}

function Overview_drawMap(nextLine) {
  Board.printAt(96,2, " Map                          ", "stInfoHeader"); 
  nextLine = 3;
  if(IS_ROOM_VISIBLE(Logic.state.currLocation)) {
    if(Logic.state.currLocation!= null && Logic.state.currLocation.render != null) {
      Board.printAt(96, nextLine, Logic.state.currLocation.render);
      currLoc = Logic.state.currLocation;
      
      ox = 96;
      oy = nextLine;
      for(content = currLoc.ll_child; content != null; content = content.ll_next) {
        if(content.icon) {
          Board.printAt(ox + content.x*2, oy + content.y, content.icon).on("click",{ act : "location", what : content}, Logic.interact);  
        }      
      }
    } else {
      Board.printAt(96, nextLine, "Describe me!");
    }
    
    nextLine++;  
        
  } else {
    Board.printAt(96, nextLine, "No visual feed.");
    nextLine++;
  }
  
  return nextLine;
}

function Overview_drawChatter(nextLine) {
  Board.printAt(128,2," Chatter                                                    ", "stInfoHeader");
  chatterLog = Logic.state.chatterLog;

  nextLine = 3;
	currentRead = Logic.state.chatterLogRead;
	for(var i=0; i < CHATTER_LOG_MAX; i++) {
		str = chatterLog[currentRead];
    currentRead ++;
    if(currentRead > CHATTER_LOG_LENGTH) currentRead = 0;
		Board.printAt(128, nextLine++, str);	
	}		 
}

function Overview_drawStory() {
  Board.printAt(32, 2," Story                                                                            ", "stInfoHeader");
  nextLine = 3; 
  storyNode = Logic.state.storyNode;
  
  storyLines = MAKE_READABLE(storyNode.text, 81);
  for(var i=0;i<storyLines.length;i++) {
    Board.printAt(32, nextLine, storyLines[i]);
    nextLine++;
  }
  
  nextLine++;
  
  for(var i=0;i<storyNode.choices.length;i++) {
    choice = storyNode.choices[i];
    Board.printAt(32, nextLine, choice.text, "stGreen").on("click",{ act : "storyChoose", what : choice}, Logic.interact); 
    nextLine++;
    nextLine++;    
  }  
}

function Overview_drawTargetOptions(nextLine) {
  Board.printAt(32,nextLine," Target                       ", "stInfoHeader");  
  nextLine++;
  
  cell = Board.printAt(32,nextLine,"Pick up", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(32,nextLine,"Drop", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++;
  cell = Board.printAt(32,nextLine,"Stash", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++; 
  cell = Board.printAt(32,nextLine,"Equip", "stGreen").on("click", { act : "gui", what : GuiCommandEnum.NONE}, Logic.interact);
  nextLine++; 

  return nextLine;
}