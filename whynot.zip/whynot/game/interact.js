Logic.interact = function(event) {
  req = event.data;
  if(req.act) {
    
    if(req.act == "targetItem") {
      Logic.state.target.type = SelectionEnum.ITEM;
      Logic.state.target.data = req.what;
    } else if(req.act == "storyChoose") {
      choice = req.what;
      
      Story.choose(choice);
    
    } else if(req.act == "crew") {
      //if(Logic.state.who.type != SelectionEnum.CREW && Logic.state.who.type != SelectionEnum.NONE) {
      //  Logic.clearSelection();
      //}
      
      Logic.state.who.type = SelectionEnum.CREW;
      Logic.state.who.data = req.what;
      
      Logic.event("selected", {type : SelectionEnum.CREW, data : req.what});
    } else if(req.act == "gui") {
      Logic.state.guiCommand = req.what;
    }
    
    else if (req.act == "location") {
      Logic.clearSelection();
      
      Logic.state.who.type     = SelectionEnum.ROOM;
      Logic.state.who.index    = req.what;
      Logic.state.currLocation = req.what;
    }
    
    else if (req.act == "crew_move") {
      // For now just move the crew
      if(Logic.state.who.type == SelectionEnum.CREW) {
        crew = Logic.state.who.data;
        targetLoc = req.what;
        prevLoc = crew.ll_location;
        MOVE_TO(targetLoc, crew);
        Logic.event("crew_moved", {from : prevLoc, to : targetLoc, data : crew});
      }
      
      //Logic.state.who.type     = SelectionEnum.ROOM;
      //Logic.state.who.index    = req.what;
      //Logic.state.currLocation = req.what;
      
      Logic.clearSelection();
    }
       
    else if (req.act == "dig") {      
      targetLoc = req.what;
      prevLoc = crew.ll_location;
    
      Logic.cLog("Cannot dig in the following room");      
      Logic.clearSelection();
    }
  } 
  Logic.performAction();  
}