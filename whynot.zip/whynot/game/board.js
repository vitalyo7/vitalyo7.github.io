Board = {
	screenController : {
		x : 0,
		y : 0,
    origin    : null,
		cellArray : [],
    allCells : null,
    regCells : null,
    MAXX : 226,
    MAXY : 59,
    CELL_LENGTH : 7.7, 
    CELL_HEIGHT : 15.45
	}
};

Board.init = function() {			
	grid = $("#grid");

  con = Board.screenController;
	
  /*
	for (var j=0;j<=con.MAXY;j++) {
		var cellRowArray = [];			
		cell = null;
		for(var i=0;i<con.MAXX;i++) {			
			//width : 90px;
			//height: 22px;
			
			cell = $("<div>", { class: "cell"});
			cell.css("top",  j * con.CELL_HEIGHT);
			cell.css("left", i * con.CELL_LENGTH);
			cell.css("z-index", (con.MAXY-j)*con.MAXY + con.MAXX-i);
			
			if(j == 0 || j == con.MAXY) {
				cell.addClass("stHeader");
			} else {
				cell.addClass("regCell");				
			}
			
      cell.data("x", i);
      cell.data("y", j);
      
			//cellRowArray.push(cell)				
			//grid.append(cell);							
		}			
		Board.screenController.cellArray.push(cellRowArray);				
	}

  con.allCells = $(".cell");
  con.regCell = $(".regCell");
  */
  
  grid.width(con.CELL_LENGTH * con.MAXX);
  grid.height(con.CELL_HEIGHT * con.MAXY);
  
  con.origin = $("<div>");
  grid.append(con.origin);
}

Board.cls = function() {
  con = Board.screenController;
  con.origin.empty();
	//Board.screenController.allCells.empty().off("click");
	//Board.screenController.regCells.removeClass ("stNormal stInfoHeader stCritical stGreen stInfoHeaderCen");
	//Board.screenController.regCells.addClass("stNormal");		
}

Board.at = function(x, y) {
	Board.screenController.x = x;
	Board.screenController.y = y;
	return Board.screenController.cellArray[y][x];		
}

Board.printAt = function(x, y, text, style) {
	//Board.screenController.x = x;
	//Board.screenController.y = y;
  
	//cell = Board.screenController.cellArray[y][x];
  con = Board.screenController;
 
  cell = $("<div>", { class: "cell"});
  cell.css("top",  y * con.CELL_HEIGHT);
  cell.css("left", x * con.CELL_LENGTH);
  cell.css("z-index", y*con.MAXX + x);  
	cell.append(text);
  
  con.origin.append(cell);
   
	if(style) {
		cell.addClass(style);
	} else {
    cell.addClass("stNormal");
  }
	return cell;
}

Board.clickAt = function(x, y, func, data) {
  /*
	Board.screenController.x = x;
	Board.screenController.y = y;
	cell = Board.screenController.cellArray[y][x];
	cell.off("click");
	cell.on("click", data, func);
  */
	return cell;
}