function generateChatter() {
  
}