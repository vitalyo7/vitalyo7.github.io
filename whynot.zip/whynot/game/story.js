Story = {
  CHAPTER1_CRASH_LANDING : null,
};

class StoryNode {
  constructor() {
		this.text        =  "";
    this.choices     = [];
    this.compileFunc = null;
	}	  
}

class StoryChoice {
  constructor() {
    this.text     = "";
    this.leadsTo  = null;
  }
}

Story.initiateStoryMode = function() {
  Logic.state.interaction_flags = SET_BIT(Logic.state.interaction_flags, GameInteractionFlag.WAITING_FOR_STORY);
}

Story.exitStoryMode = function() {
  Logic.state.interaction_flags = UNSET_BIT(Logic.state.interaction_flags, GameInteractionFlag.WAITING_FOR_STORY);
}

Story.init = function() {
  // Chapter 1
  node = new StoryNode();
  node.text = 
  "(distant sounds of alarms ringing)";
  Story.CHAPTER1_CRASH_LANDING = node;  
  
  node_awake = new StoryNode();
  node_awake.text = 
  "You lazily open your eyes, and squint as soon as you notice bright red emergency lights flashing outside your cryo chamber."+
  "The alarm sounds become more clear as you become more awake. It is definitely not a dream, something bad must have happened.";

  choice          = new StoryChoice();
  choice.text     = "Wake up";
  choice.leadsTo = node_awake;
  node.choices.push(choice);
  
  node_climb_out = new StoryNode();
  node_climb_out.compileFunc = function() {
    node_climb_out.text +=
"The cryochamber door opens with a small hiss. As you climb out of the cryopod you nearly collapse on the rubber coated floor,"+
" your limbs feel numb - still recovering from the hypersleep. The cryosleep room is poorly lit, and aside from the emergency "+
"lights and cryopod equipment, there is not much to go on. You notice some of the crew already dressing themselves and trying "+
"to get a fix on the situation.";
    node_climb_out.text += "\n" + CREW(1).fname + " extends you their arm to help you up and asks \"Are you ok, "+CREW(0).fname+"?\"";    
  };
  
  choice          = new StoryChoice();
  choice.text     = "Push the open button and climb out";
  choice.leadsTo  = node_climb_out;
  node_awake.choices.push(choice);
     
  node_what_happened = new StoryNode();
  node_what_happened.compileFunc = function() {
    node_what_happened.text +=
    CREW(1).fname+" shakes their head, \"Don't know, it looks like we have been hit by something.\". "+
    CREW(2).fname+" and "+CREW(3).fname+" are standing by the room's monitor console, studying it's readouts. "+
    CREW(2).fname+" adds \"The output is garbled and readings don't make much sense. I am not able to reach "+
    " central core or majority of the systems aboard the ship. To make things worse, we are losing life support "+
    "here as well. I recommend we suit up in EVA gear. Hope you all remember your emergency procedures.\"\n"+
    CREW(3).fname + " nods to "+CREW(2).fname+".";
    
    
  };
  
  choice          = new StoryChoice();
  choice.text     = "Get up and ask \"What happened?\"";
  choice.leadsTo  = node_what_happened;
  node_climb_out.choices.push(choice);
}

Story.choose = function(choice) {
  targetNode =choice.leadsTo;
  Logic.state.storyNode = targetNode;
  if(targetNode.compileFunc) {
    targetNode.compileFunc();
  }
}
