CHATTER_LOG_LENGTH = 80;
CHATTER_LOG_MAX    = 40;

class MissionLog {
	constructor(txt, date) {
		this.date = date;
		this.txt = txt;		
	}
}

class Person {
	constructor() {
		this.name      = "A. Person";
		this.isAlive   = true;
    
    this.stateFlags  = 0;
    this.actionFlags = 0;
		
    this.nutrition = 96*2;//Logic.rng(4) + 1;
		
    this.doing       = ActionEnum.IDLE;
    this.designation = DesignationEnum.CIVILIAN;
    
    this.inventory = [];
    for(var i=0; i < EquipSlotEnum.EQUIP_MAX; i++) {
      this.inventory.push(null);
    }
	}	
}

class Room {
  constructor(name) {
		this.name   = name;
    this.descr  = null;
    this.render = null;
    
    this.viewFlags = 0;
	}	  
}

class Item {
  constructor(name) {
    this.name = name;
    this.equip_slot = EquipSlotEnum.HOLDING;
	}	  
}

GameLib = {
  goids : {},
  tags : {},
  item_templates : {
  
  }
};

Help = {
  20002 : "A lightwave rifle, made of carbon fibre alloys.",
  20003 : "A tool used for creating short range sonic fields that distabilize rock formation. Ideal for mining."
};

var EquipSlotEnum = {
	"CLOTHING"  : 0, 
	"HOLDING"   : 1, 
	"EQUIPMENT" : 2,
	"UTILITY"   : 3,
  "BACKPACK"  : 4,
  "BELT"      : 5,
  "STORE1"    : 6,
  "STORE2"    : 7,
  "STORE3"    : 8,
  "STORE4"    : 9,
  "STORE5"    : 10,
  "EQUIP_MAX" : 11
};
Object.freeze(EquipSlotEnum);

var RoomViewEnum = {
	"VISIBLE"         : 1, 
	"DISCOVERED"      : 2, 
	"ALWAYS_VISIBLE"  : 4,
	"CAVED_IN"        : 8  
};
Object.freeze(RoomViewEnum);

var GameInteractionFlag = {
  "NONE           "     : 0,
  "WAITING_FOR_STORY"   : 1  
};
Object.freeze(GameInteractionFlag);

var SelectionEnum = {
	"NONE"      : 0, 
	"CREW"      : 1, 
	"PLACE"     : 2,
	"ITEM"      : 3
};
Object.freeze(SelectionEnum);

var GuiCommandEnum = {
	"NONE"               : 0,
  "CREW_SELECTION"     : 1,
  "CREW_EQUIPMENT"     : 2,
  "CREW_MOVEMENT"      : 3,
  "CREW_ACTION"        : 4,
  "CREW_INFORMATION"   : 5,
  "BUILD_SELECTION"    : 6,
  "LOCATION_SELECTION" : 7,
};
Object.freeze(GuiCommandEnum);

var ActionEnum = {
	"IDLE"      : 0, 
	"SLEEPING"  : 1, 
	"RESEARCH"  : 2,
	"GUARDING"  : 3
};
Object.freeze(ActionEnum);

var ActionFlags = {
  IDLE   : 0,
  MOVING : 1,
}
Object.freeze(ActionFlags);

var DesignationEnum = {
  "CIVILIAN" : 0,
  "MINER"    : 1,
  "SALVAGER" : 3,
  "ORE_MINER": 4,
  "CARGO"    : 5,
  "ENGINEER" : 6
};
Object.freeze(DesignationEnum);

var ScreenEnum = {
  "OVERVIEW_SCREEN"     : 0,
  "CREW_PERSON_INFO"    : 1,
  "CREW_JOB_ASSIGNMENT" : 2
};
Object.freeze(ScreenEnum);

var JobHandlers = {};
var DesignationHandlers = {};

function addAction(actId, actObj) {
  JobHandlers[actId] = actObj;
}

function addDesignation(designationId, desObj) {
  DesignationHandlers[designationId] = desObj;
}

addAction(ActionEnum.IDLE, {
  statusStr : "idle"
});

addAction(ActionEnum.SLEEPING, {
  statusStr : "sleeping"
});

addAction(ActionEnum.RESEARCH, {
  statusStr : "researching"
});

addAction(ActionEnum.GUARDING, {
  statusStr : "guarding"
});


addDesignation(DesignationEnum.CIVILIAN, {
  statusStr : "Civilian"
});

addDesignation(DesignationEnum.MINER, {
  statusStr : "Miner"
});

addDesignation(DesignationEnum.CARGO, {
  statusStr : "Cargo"
});

addDesignation(DesignationEnum.ENGINEER, {
  statusStr : "Engineer"
});

class Mission {
  constructor() {
    this.name      = "Mission";
    this.started   = false;
    this.active    = false;
    this.ticks     = 0;
    this.remaining = 0;
    this.onEnd     = null;
  }  
}

GameLib.init = function() {
  
}

GameLib.add = function (goid, construct, tags) {
  GameLib.goids[goid] = construct;
  if(tags) {
    tags.forEach(function (tag) {
        if(!(tag in GameLib.tags)) {
          GameLib.tags[tag] = [];
        }
        
        GameLib.tags[tag].push(goid);      
    });
  }
}

GameLib.spawn = function(goid) {
  obj = GameLib.goids[goid]();
  
  obj.goid = goid;
     
  obj.ll_location = null;
  obj.ll_child    = null;
  obj.ll_next     = null;
  
  return obj;
}

GameLib.add(10001, function () {
  p = new Person();
  
  p.fname     = "Jose";
  p.lname     = "Sanchez";
	p.name      = "J. Sanchez";
	p.doing     = ActionEnum.SLEEPING;
    
  return p;
}, ["starter_mob"]);

GameLib.add(10002, function () {
  p = new Person();
  
  p.fname     = "Lana";
  p.lname     = "Orkut";
	p.name      = "L. Orkut";
	p.doing     = ActionEnum.RESEARCH;
    
  return p;
}, ["starter_mob"]);

GameLib.add(10003, function () {
  p = new Person();
  
  p.fname     = "Pavel";
  p.lname     = "Utuzov";
	p.name      = "P. Utuzov";
	p.doing     = ActionEnum.GUARDING;
    
  return p;
}, ["starter_mob"]);

GameLib.add(10004, function () {
  p = new Person();
  
  p.fname     = "Sergey";
  p.lname     = "Lazarev";
	p.name      = "S. Lazarev";
	p.doing     = ActionEnum.RESEARCH;
    
  return p;
}, ["starter_mob"]);


GameLib.add(20001, function () {
  i = new Item();  
	i.name      = "space suit";
  i.equip_slot = EquipSlotEnum.CLOTHING;  
  return i;
});

GameLib.add(20002, function () {
  i = new Item();  
	i.name      = "laser rifle";  
  i.equip_slot = EquipSlotEnum.EQUIPMENT;   
  return i;
});

GameLib.add(20003, function () {
  i = new Item();  
	i.name      = "sonic resonator";  
  i.equip_slot = EquipSlotEnum.EQUIPMENT;   
  return i;
});

GameLib.add(30001, function () {
  r      = new Room();  
	r.name = "Crash site";
  r.render =     
    "                \n"+
    "..              \n"+
    "[]..            \n"+
    "[]..            \n"+
    "..              \n"+
    "                \n"+
    "                \n"+
    "                \n";
  r.icon = "<span style='color:yellow'>cs</span>";
  r.x    = 4;
  r.y    = 2; 
  r.description = "Crash site of the emergency pod. There is a large crater where the pod has landed. Most of the vegetation around the impact crater has burned out.";
  return r;
});

GameLib.add(30002, function () {
  r      = new Room();  
	r.name = "World";
  r.render = "· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n";
  r.viewFlags = SET_BIT(r.viewFlags, RoomViewEnum.ALWAYS_VISIBLE);
  return r;
});

GameLib.add(30003, function () {
  r      = new Room();  
	r.name = "Eastern Wastes";
  r.viewFlags = SET_BIT(r.viewFlags, RoomViewEnum.ALWAYS_VISIBLE);
  r.icon = "<span style='color:yellow'>..</span>";
  r.render = "· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n· · · · · · · ·  \n";
  r.x    = 5;
  r.y    = 5;
  return r;
});

GameLib.add(30004, function () {
  r      = new Room();  
	r.name = "Base";
  r.render = 
    "            ^^^^\n"+
    "          ^^^^^^\n"+
    "        ^^^^nw^^\n"+
    "        ..wwceew\n"+
    "          ^^so^^\n"+
    "            ^^^^\n"+
    "            ^^^^\n"+
    "              ^^\n";
  r.icon = "<span style='color:green'>ba</span>";
  r.x    = 6;
  r.y    = 3; 
  r.description = "This is the base, hidden inside a mountain, it is protected from the harsh environment of the planet.";
  r.viewFlags = SET_BIT(r.viewFlags, RoomViewEnum.ALWAYS_VISIBLE);
  return r;
});

GameLib.add(30005, function () {
  r      = new Room();  
	r.name = "Base Exterior";
  r.render = 
    "     ..     ^^^^\n"+
    "  ..        ^^^^\n"+
    "            ^^^^\n"+
    "     ..     [  ]\n"+
    "  ..        ^^^^\n"+
    "         .. ^^^^\n"+
    "  ...  ..   ^^^^\n"+
    "            ^^^^\n";
  r.icon = "<span style='color:yellow'>..</span>";
  r.x    = 4;
  r.y    = 3; 
  r.description = "An external area of the base.";
  return r;
});

GameLib.add(30006, function () {
  r      = new Room();  
	r.name = "West Wing";
  r.render2 = 
    "····[][]········\n"+  
    "····[][][]······\n"+
    "[][][][][]······\n"+
    "····[][]········\n"+
    "····[]··········\n"+
    "··[][][]········\n"+  
    "····[]··········\n"+ 
    "················\n";
  r.render = 
    "················\n"+  
    "····[][]········\n"+
    "[][][][][]······\n"+
    "··[][]··········\n"+
    "················\n"+
    "················\n"+  
    "················\n"+ 
    "················\n";
  r.icon = "<span style='color:green'>ww</span>";
  r.x    = 5;
  r.y    = 3; 
  r.description = "This is the base, hidden inside a mountain, it is protected from the harsh environment of the planet.";
  r.viewFlags = SET_BIT(r.viewFlags, RoomViewEnum.ALWAYS_VISIBLE);
  return r;
});

GameLib.add(30007, function () {
  r      = new Room();  
	r.name = "Caved Room";  
  r.icon = "<span class='stGreen'>oo</span>";
  r.description = "This is the base, hidden inside a mountain, it is protected from the harsh environment of the planet.";
  r.viewFlags = SET_BIT(r.viewFlags, RoomViewEnum.ALWAYS_VISIBLE);
  return r;
});
