function DESIGNATION_FOR_MOB(person) {
  return DesignationHandlers[person.designation];
}

function SELECTED_MOB() {
  return Logic.state.who.data;
}

function EQUIP_MOB(mob, equipment) {
  mob.inventory[equipment.equip_slot] = equipment;
}

function CREW(i) {
  return Logic.state.crew[i];
}

function IS_SET(flag, bit) {
  if ((flag & bit) != 0) return true;
  return false;
}

function SET_BIT(flag, bit) {
  return flag | bit;
}

function UNSET_BIT(flag, bit) {
  return flag &= ~bit;  
}

function IS_ROOM_VISIBLE(room) {
  if(IS_SET(room.viewFlags, RoomViewEnum.ALWAYS_VISIBLE)) return true;
  crewRef = Logic.state.crew;
  for(i=0; i < crewRef.length; i++) {
    crew = crewRef[i];
    if(crew.ll_location == room) return true;
  }
  return false;
}

function MOVE_TO(location, node) {
  if(node.ll_location != null) LL_REMOVE(node.ll_location, node);
  if(location != null) LL_ADD(location, node);
}

function LL_ADD(location, node) { 
  if(location.ll_child == null) {
    location.ll_child = node;
  } else {
    for(curr = location.ll_child; curr.ll_next != null; curr = curr.ll_next);
    curr.ll_next = node;
    node.ll_next = null;   
  }  
  node.ll_location = location;
}

function LL_REMOVE(location, node) {
  
  if(location.ll_child == node) {
    location.ll_child = node.ll_next;
  } else {
    prev = null;
    for(curr = location.ll_child; curr != null; curr = curr.ll_next) {
      if(curr == node) {
        prev.ll_next = curr.ll_next;
        break;
      }
      prev = curr;
    }    
  }
  
  node.ll_location = null;
  node.ll_next  = null;
}

function CHUNK_STRING(str, size) {
  const numChunks = Math.ceil(str.length / size)
  const chunks = new Array(numChunks)

  for (let i = 0, o = 0; i < numChunks; ++i, o += size) {
    chunks[i] = str.substr(o, size)
  }

  return chunks
}

function MAKE_READABLE(str, size, tags) {
  var lines = [];
  nextTag = 0;
  tag     = null;
  
  var chapters = str.split(/\n/);
  for(var j=0; j < chapters.length;j++) {
    chapter = chapters[j];
    
    lines.push("");
    currLength = 0;
     
    words = chapter.split(/\s+/);
    
    for(var i=0; i<words.length;i++) {
      word = words[i];
      
      needLength = 0;
      if(word.startsWith("^[tag]")) {
        tag  = tags[nextTag++];
        
        remainder = word.substring(6);
        word = tag.name;
                
        needLength = tag.name.length + remainder.length + 1;
        
        element = $("<span>", { id : tag.id});
        element.append(word);
        
        tag.el = element;
        
        word = element.prop('outerHTML') + remainder;        
      } else {
        needLength = word.length + 1;
      }         
      
      if(currLength + needLength < size) {
        lines[lines.length-1] += word +" ";
      } else {
        lines.push("");
        currLength = 0;
        lines[lines.length-1] += word + " ";
      }
      currLength += needLength;
    }
  }
  
  return lines;
}

function LIST_APPEND_LIST(list1, list2, prefix, suffix) {
  list2.forEach(function(el) {
    line = el;
    if(prefix) {
      line = prefix + line;
    }
    if(suffix) {
      line = line + suffix;
    }
    list1.push(line);
  }); 
}

function LIST_COMMA_READABLE(list) {
  if(list.length == 0) return "";
  if(list.length == 1) return list[0];
  
  beforeLast = list.length - 2;
  str = "";
  for(var i=0; i < list.length; i++) {
    str += list[i];
    if(i < beforeLast) {
      str += ", ";
    } else if (i == beforeLast) {
      str += " and ";
    }
  }
  return str;
}