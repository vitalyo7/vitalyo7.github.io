Logic = {
	state : {
		dateCount  : 0,
		missionLog : [],

		crew       : [],
    missions   : [],
    
    game_flags : 0,
    interaction_flags : 0,
    
    storyNode : null,
    
		isGameOver : false,
    
    chatterLog      : [],
    chatterLogRead  : 0,
    chatterLogWrite : 0,
    
    currLocation : null,

    currScreen     : 0,
    guiCommand     : GuiCommandEnum.NONE,
    who            : { type : SelectionEnum.NONE, data : null},
    target         : { type : SelectionEnum.NONE, data : null},
    action         : {}   
    
	}	
};

Logic.init = function() {  
	Logic.reset();
}

Logic.rng = function(n) {
	return Math.floor(Math.random() * n);
}

Logic.reset = function() {
	Logic.state.dateCount  = 28;
	Logic.state.missionLog = [];
	Logic.state.crew       = [];
  Logic.state.missions   = [];
	Logic.state.isGameOver = false;
  
  Logic.state.game_flags        = 0;
  Logic.state.interaction_flags = 0;
  Logic.state.storyNode         = null;
  
  Logic.state.chatterLog = [];
  for(var i=0; i < CHATTER_LOG_LENGTH; i++) {
    Logic.state.chatterLog.push("");
  }
  Logic.state.chatterLogRead = 0;
  Logic.state.chatterLogWrite = 0;
  
  Logic.clearSelection();
  
  // Current room
  world     = GameLib.spawn(30002);
  wastes    = GameLib.spawn(30003);
  crashSite = GameLib.spawn(30001);
  base      = GameLib.spawn(30004);
  Logic.state.currLocation = crashSite;
  
  MOVE_TO(world, wastes);
  MOVE_TO(wastes, crashSite);
  MOVE_TO(wastes, base);
  
  MOVE_TO(base, GameLib.spawn(30005));
  
  ww = GameLib.spawn(30006);
  MOVE_TO(base, ww);
  
  caved = GameLib.spawn(30007);caved.x = 2; caved.y = 1;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 3; caved.y = 1;MOVE_TO(ww, caved);  
  caved = GameLib.spawn(30007);caved.x = 0; caved.y = 2;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 1; caved.y = 2;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 2; caved.y = 2;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 3; caved.y = 2;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 4; caved.y = 2;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 1; caved.y = 3;MOVE_TO(ww, caved);
  caved = GameLib.spawn(30007);caved.x = 2; caved.y = 3;MOVE_TO(ww, caved);
   
  starter_goids = GameLib.tags["starter_mob"].slice();
  for(var i=0; i<4; i++) {
    
    index = Logic.rng(starter_goids.length);
    goid = starter_goids[index];
    
    // Remove the element so we don't repeat
    starter_goids.splice(index, 1);
    
    newPerson = GameLib.spawn(goid);
    Logic.state.crew.push(newPerson); 

    MOVE_TO(crashSite, newPerson);
    
    // Give some items
    suit = GameLib.spawn(20001);
    EQUIP_MOB(newPerson, suit);
  }
  
  // Move some items to crash site
  MOVE_TO(crashSite, GameLib.spawn(20002));
  MOVE_TO(crashSite, GameLib.spawn(20002));
  MOVE_TO(crashSite, GameLib.spawn(20003));
	
	Logic.mLog("While travelling through hyperspace, our ship hit an anomaly, resulting in catastrophic failure.");
  Logic.mLog("The crew escaped in emergency pods, but the fate of the ship is unknown, likely crashed.");	   
  Logic.mLog("(Story) We need to salvage some supplies and find shelter.");
  
  mission = new Mission();
  
  mission.name      = "Salvage";
  mission.started   = true;
  mission.active    = true;
  mission.ticks     = 0; // 3 hours
  mission.remaining = 12; // 3 hours
  mission.onEnd     = null;
     
  Logic.state.missions.push(mission); 

  //Logic.state.storyNode = Story.CHAPTER1_CRASH_LANDING;
  //Story.initiateStoryMode();
  
	Logic.selectOverview();  
}

Logic.mLog = function(txt) {
	Logic.state.missionLog.push(new MissionLog(txt, Logic.state.dateCount));	
}

Logic.cLog = function(txt) {
	Logic.state.chatterLog[Logic.state.chatterLogWrite++] = txt;
  if(Logic.state.chatterLogWrite > CHATTER_LOG_LENGTH) Logic.state.chatterLogWrite = 0;
  
  diff = Math.abs(Logic.state.chatterLogWrite - Logic.state.chatterLogWrite);
  if(diff > CHATTER_LOG_MAX) {
    Logic.state.chatterLogRead++;
  }
  
  if(Logic.state.chatterLogRead > CHATTER_LOG_LENGTH) Logic.state.chatterLogRead = 0;
}


Logic.redraw = function() {
  switch(Logic.state.currScreen) {
    case ScreenEnum.OVERVIEW_SCREEN:
      Logic.drawOverview();
    break;    
  }
}

Logic.selectLog = function() {
  Board.cls();	
	Board.printAt(60,0,  "   Back   ", "stHeader").on("click", Logic.selectOverview); 
  
  mLogRef = Logic.state.missionLog
	Board.printAt(0, 1, "Log_____________________________________________________________________________________________________________", "stInfoHeader");
	
	oldLogDate = -1;
	for(var i=0; i < mLogRef.length; i++) {
		logEntry = mLogRef[i];
		if(oldLogDate != logEntry.date) {
			Board.printAt(0, 2+i, Logic.dateToStr(logEntry.date));		
			oldLogDate = logEntry.date;
		}
		Board.printAt(15, 2+i, logEntry.txt);	
	}		 
}

Logic.selectMap = function() {
  Board.cls();
	
	Board.printAt(60,0,  "   Back   ", "stHeader").on("click", Logic.selectOverview); 
    
  var BX=50;
  var BY=23;
  /*
  var gridBuffer = "╔";   
  for(var i=0; i < BX; i++) gridBuffer += "═══";  
  gridBuffer += "\n"; 
  for(var j=0; j < BY; j++) {    
    gridBuffer += "║";
    for(var i=0; i < BX; i++) gridBuffer += "  ║";  
    gridBuffer += "\n"; 

    gridBuffer += "╠";
    for(var i=0; i < BX; i++) gridBuffer += "══╬";  
    gridBuffer += "\n";
  }  
  Board.printAt(0, 1, gridBuffer);
  */
  Board.printAt(4,    1, "WARNING", "stGreen");
    
  Board.printAt(40,  20, "[Crash site]", "stGreen");
  Board.printAt(54,  18, "[???]", "stGreen");
  
  /*
  var xOff = 1;
  var yOff = 2;
  for(var j=2; j < BY+2; j++) { 
  Board.printAt(xOff, yOff, "xx");
  xOff+=3;  
  yOff+=2;
  }
  */
  Board.printAt(150, 49, "@");
  
}

Logic.dateToStr = function (date) {
  day = 1 + Math.floor(date / 96);
  time = date % 96;
  hour = Math.floor(time / 4);
  min  = (time % 4) * 15;
  if(min == 0) {min = "00";}
  return "Day "+day+", "+hour+":"+min;
}

Logic.timeToStr = function (time) {
  hour = Math.floor(time / 4);
  min  = (time % 4) * 15;
  if(min == 0) {min = "00";}
  return hour+":"+min;
}


Logic.selectCrew = function() {
	Board.cls();
  
  Board.printAt(0,0,  "   Crew   ", "stHeader").on("click", Logic.selectCrew);
	Board.printAt(50,0, "   Back   ", "stHeader").on("click", Logic.selectOverview);

	crewRef = Logic.state.crew;
	Board.printAt(0, 1,  "Name                                                                            ",   "stInfoHeader");
  Board.printAt(15, 1, "Job",   "stInfoHeader");
  Board.printAt(30, 1, "Doing", "stInfoHeader");
  
  vEmpty  = '\u25CB';
  vFull   = '\u25CF';
  vDotted = '\u25CC';
  
  nextLine = 2;
	for(i=0; i < crewRef.length; i++) {

    crew = crewRef[i];    
    crewCell = null;
    
    if(!crew.isAlive) {
      crewCell = Board.printAt(0, nextLine, crew.name, "stCritical");	
      Board.printAt(15, nextLine, "dead", "stCritical");      
    } else {
      crewCell = Board.printAt(0, nextLine, crew.name, "stGreen");
      Board.printAt(15, nextLine, DESIGNATION_FOR_MOB(crew).statusStr);        
      Board.printAt(30, nextLine, JobHandlers[crew.doing].statusStr);      
      
      //Board.printAt(3, crewRow, vDotted+vDotted+vDotted+vDotted+vDotted);
      //Board.printAt(4, crewRow, vFull+vFull+vFull+vFull+vFull);
      //Board.printAt(5, crewRow, vEmpty+vEmpty+vEmpty+vEmpty+vEmpty);
    }

    crewCell.on("click", i, Logic.displayCrewInfo);
    nextLine++;
	}	

  nextLine += 1;
  currScreen = Logic.state.currScreen;
  if(Logic.state.currWho != -1 && currScreen == ScreenEnum.CREW_PERSON_INFO || currScreen == ScreenEnum.CREW_JOB_ASSIGNMENT) {
    
    crew = crewRef[Logic.state.currWho];
    
    Board.printAt(0, nextLine, "Crew Information                                                                ", "stInfoHeader");
    nextLine++;
    
    Board.printAt(0, nextLine, "Name:");
    Board.printAt(15, nextLine, crew.name);    
    nextLine++;
            
    Board.printAt(0, nextLine, "Job:");
    Board.printAt(15, nextLine, DESIGNATION_FOR_MOB(crew).statusStr, "stGreen").on("click", 
      function() {
        Logic.state.currScreen = ScreenEnum.CREW_JOB_ASSIGNMENT;
        Logic.selectCrew();
      }
    );    
    nextLine++;
    
    if(currScreen == ScreenEnum.CREW_JOB_ASSIGNMENT) {
      nextLine++;
      Board.printAt(0, nextLine,  "Select new job assignment:                                                     ", "stInfoHeader");
      nextLine++;
      Board.printAt(0, nextLine,  "Generic                                                                        ", "stInfoHeader");
      Board.printAt(15, nextLine, "Service", "stInfoHeader");
      Board.printAt(30, nextLine, "Engineering", "stInfoHeader");
      
      nextLine++;
      Board.printAt(0, nextLine,  "Civilian       ", "stGreen").on("click", DesignationEnum.CIVILIAN, Logic.assignJob)
      Board.printAt(15, nextLine, "Mining         ", "stGreen").on("click", DesignationEnum.MINER,    Logic.assignJob);
      Board.printAt(30, nextLine, "Engineer       ", "stGreen").on("click", DesignationEnum.ENGINEER, Logic.assignJob);
      
      nextLine++;
      Board.printAt(15, nextLine, "Cargo          ", "stGreen").on("click", DesignationEnum.CARGO, Logic.assignJob);
    }
  }  
}

Logic.displayCrewInfo = function (event) {
  selectedCrew = event.data;

  Logic.state.currScreen = ScreenEnum.CREW_PERSON_INFO;
  Logic.state.currWho    = selectedCrew;

  Logic.selectCrew();
}

Logic.assignJob = function (event) {
  job = event.data;

  Logic.state.currScreen = ScreenEnum.CREW_PERSON_INFO;
  
  crewRef = Logic.state.crew;
  crew    = crewRef[Logic.state.currWho];
  crew.designation = job;  

  Logic.selectCrew();
}


Logic.selectMission = function() {  
	Board.cls();
	Board.printAt(50,0, "   Back   ", "stHeader").on("click", Logic.selectOverview);
  	
	Board.printAt(0, 1,  "Mission   ",   "stInfoHeader");
  Board.printAt(10, 1, "Status    ",   "stInfoHeader");
  Board.printAt(20, 1, "Remaining ",   "stInfoHeader");
    
  missionRef = Logic.state.missions;
  //Board.printAt(0, 2,  "Salvage Op");	
 // Board.printAt(1, 2,  "Started");	
  //Board.printAt(0, 3,  "Find Shelter");	
 // Board.printAt(1, 3,  "Available");	
  
  vEmpty  = '\u25CB';
  vFull   = '\u25CF';
  vDotted = '\u25CC';
  
	for(var i=0; i < missionRef.length; i++) {
    missionRow = 2+i;
    mission = missionRef[i];
    
    Board.printAt(0, missionRow, mission.name);	
    Board.printAt(10, missionRow, mission.started);
    Board.printAt(20, missionRow, Logic.timeToStr(mission.remaining));       
	}	

}

Logic.selectNextTurn = function() {
	Logic.state.dateCount++;	
	if(Logic.state.isGameOver) return;
	
	// Check on crew
	crewRef = Logic.state.crew;
	for(var i=0; i < crewRef.length; i++) {
		crew = crewRef[i];
		if(crew.isAlive == false) continue;
		
		crew.nutrition--;
		if(crew.nutrition <= 0) {
			crew.isAlive = false;
			Logic.mLog(crew.name +" has died of malnutrition.");
		}
	}
  
  missionRef = Logic.state.missions;
  for(var i=0; i < missionRef.length; i++) {
    mission = missionRef[i];
    
    if(mission.active && mission.remaining > 0) {
      mission.remaining--;
      if(mission.remaining == 0) {
        mission.active = false;
        Logic.mLog("Mission '"+mission.name+"' was completed.");
        
      }
    }
	}	
	
	Logic.checkEndGame();	
	Logic.selectOverview();	
}

Logic.checkEndGame = function() {
	if(Logic.state.isGameOver) return;
	
	// Check if all crew is alive
	crewRef   = Logic.state.crew;
	crewAlive = 0;
  
   
	for(var i=0; i < crewRef.length; i++) {
		crew = crewRef[i];
		if(crew.isAlive == true) {
			crewAlive = 1;
			break;
		}
	}
	
	if(crewAlive <= 0) {
		Logic.state.isGameOver = true;
		Logic.mLog("<span style='color:red;'>Game over, no survivors are left.<span>");
	}
}

Logic.clearSelection = function() {
  Logic.state.guiCommand    = GuiCommandEnum.NONE;
  Logic.state.who.type      = SelectionEnum.NONE;
  Logic.state.who.data      = null;
  Logic.state.target.type   = SelectionEnum.NONE;
  Logic.state.target.data   = null;
}

Logic.performAction = function() {
  
  performedCommand = false;
  
  // Check requirements
  switch(Logic.state.guiCommand) {
    case GuiCommandEnum.NONE:
    
    break;    
  }
  
  if(performedCommand) {
    // Clear selection
    Logic.clearSelection();
  }  

  Logic.redraw();
}

Logic.event = function(evt, data) {
  if(evt == "selected") {
    if(data.type == SelectionEnum.CREW && data.data != -1) {
      Logic.cLog(data.data.name + " : 'Sup'");
    }
  } 
  else if (evt == "crew_moved")  {
    Logic.cLog(data.data.name + " has moved to "+data.to.name);
  }
}

Logic.describe = function(what, tags) {  

  if(what instanceof Item) {
    itemDesc = "";
    if(Help[what.goid]) {
      itemDesc += Help[what.goid];
    }
    
    return MAKE_READABLE(itemDesc, 61);
  }

  if(what instanceof Room) {
    typeOfObjects = {
      items : [],
      people : [],
    };           
        
    for(content = what.ll_child; content != null; content = content.ll_next) {
      if(content instanceof Person)    { typeOfObjects.people.push(content);  }
      else if(content instanceof Item) { typeOfObjects.items.push(content); }
    }
     
    returnLines = [];
    if(what.description) {
      placeDesc = "";
      placeDesc += what.description;
      LIST_APPEND_LIST(returnLines, MAKE_READABLE(placeDesc, 61));
    }
    
    if(typeOfObjects.items.length > 0) {
      objectDesc = "";
      objectDesc += "There are some items on the ground : ";
      itemList = [];
      itemIds = 0;

      typeOfObjects.items.forEach(function(item) {
        itemList.push("^[tag]");
        tags.push({
          name  : item.name,
          id    : "item"+(itemIds++),
          item  : item
        });
      });
      objectDesc += LIST_COMMA_READABLE(itemList);   
      objectDesc += ".";
      LIST_APPEND_LIST(returnLines, MAKE_READABLE(objectDesc, 61, tags),"<span class='stBlue'>", "<\span>");      
    }
    
    if(typeOfObjects.people.length > 0) {
      peopleDesc = "Following people are present : ";
      pplList = [];
      typeOfObjects.people.forEach(function(el) {
        pplList.push(el.fname);
      });
      peopleDesc  += LIST_COMMA_READABLE(pplList);
      peopleDesc += "."
      LIST_APPEND_LIST(returnLines, MAKE_READABLE(peopleDesc, 61),"<span class='stYellow'>", "<\span>");
    }
    
    return returnLines;
  }
  return [];
}